
export const SliderData = [
    {
        image:'https://static.nike.com/a/images/w_1920,c_limit,f_auto,q_auto/2552443c-592f-4231-976c-6109fe3308d1/50th-anniversary-day-3-member-access-waffle-one.jpg'
    },
    {
        image:'https://wallpaperaccess.com/full/2084071.png'
    },
    {
        image:'https://cdn.thecoolist.com/wp-content/uploads/2016/06/Adidas-Ad-Photo-The-Coolist.jpg'
    },
    {
        image:'http://images.solecollector.com/complex/image/upload/fl_lossy,q_auto/i8m595rhllwbvxg4astc.jpg'
    },
    {
        image:'https://static.nike.com/a/images/w_1920,c_limit,f_auto,q_auto/7c60eeaf-46dd-4dab-9c42-6e11ca26f9c3/50th-anniversary-day-3-member-access-waffle-one.jpg'
    },
    {
        image:'https://2.bp.blogspot.com/-6rMixsDoBZ8/W3EcqjYVchI/AAAAAAAAX78/WcGe8PlP25Q5VVIxz_j5NDKkJxX8gz_6QCLcBGAs/w1200-h630-p-k-no-nu/nike-kobe-ad-new-shoe-release-date-kobe-day-3.jpg'
    },
    {
        image:'https://i.pinimg.com/originals/02/3a/87/023a877e31bece11178bc786e058d49f.jpg'
    },
]